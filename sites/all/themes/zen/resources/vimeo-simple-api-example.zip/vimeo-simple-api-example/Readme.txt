Hi!

This is a simple example of how to use the Vimeo Simple API in Javascript
and PHP.

For the Javascript example, all you need to do is change the vimeoUserName
variable to your username and upload to your server. (Actually you don't
even need to do that, you can just open them in a web browser.)

For the PHP example, upload simple.php to your server. You can load a
different user's videos by appending ?user= and the username to the URL.

For more documentation on the API go to http://www.vimeo.com/api

- Brad Dougherty (October 1, 2008)